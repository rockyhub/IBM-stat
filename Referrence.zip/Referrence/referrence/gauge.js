$(function () {

    // Uncomment to style it like Apple Watch
    
    if (!Highcharts.theme) {
        Highcharts.setOptions({
            chart: {
                backgroundColor: '#f5f5f5'
            },
            colors: ['#b32772', '#a0dfe8', '#8dba3f', '#fff'],
            title: {
                style: {
                    color: 'silver'
                }
            },
            tooltip: {
                style: {
                    color: 'silver'
                }
            }
        });
    }
    // 

    Highcharts.chart('container', {

        chart: {
            type: 'solidgauge',
            marginTop: 50
        },

        title: {
            text: 'Usage Comparison',
            style: {
                fontSize: '18px',
                color:'#000'
            }
        },

        tooltip: false,

        pane: {
            startAngle: -160,
            endAngle: 160,
            background: [{ // Track for Move
                outerRadius: '110%',
                innerRadius: '100%',
                backgroundColor: Highcharts.Color(Highcharts.getOptions().colors[3]).get(),
                borderWidth: 0
            }, { // Track for Exercise
                outerRadius: '100%',
                innerRadius: '90%',
                backgroundColor: Highcharts.Color(Highcharts.getOptions().colors[3]).get(),
                borderWidth: 0
            }, { // Track for Stand
                outerRadius: '90%',
                innerRadius: '70%',
                backgroundColor: Highcharts.Color(Highcharts.getOptions().colors[3]).get(),
                borderWidth: 0
            }]
        },

        yAxis: {
            min: 0,
            max: 100,
            lineWidth: 0,
            tickPositions: []
        },

        plotOptions: {
            solidgauge: {
                borderWidth: '14px',
                dataLabels: {
                    enabled: false,
                    y: 5,
                    borderWidth: 0,
                    useHTML: true
                },
                linecap: 'square',
                stickyTracking: false
            }
        },

        series: [{
            name: 'Team',
            borderColor: Highcharts.getOptions().colors[0],
            data: [{
                color: Highcharts.getOptions().colors[0],
                radius: '100%',
                innerRadius: '100%',
                y: 54
            }],
            dataLabels:{
                format: '<div class="test">Team<br><span style="font-size:2em; color: {point.color}; font-weight: bold">{point.y}%</span></div>',
            }
            
        }, {
            name: 'Business Unit',
            borderColor: Highcharts.getOptions().colors[1],
            data: [{
                color: Highcharts.getOptions().colors[1],
                radius: '90%',
                innerRadius: '90%',
                y: 71
            }],
            dataLabels:{
                format: '<div class="test">Business Unit<br><span style="font-size:2em; color: {point.color}; font-weight: bold">{point.y}%</span></div>',
            }
        }, {
            name: 'IBM',
            borderColor: Highcharts.getOptions().colors[2],
            data: [{
                color: Highcharts.getOptions().colors[2],
                radius: '80%',
                innerRadius: '80%',
                y: 89
            }],
            dataLabels:{
                format: '<div class="test">IBM<br><span style="font-size:2em; color: {point.color}; font-weight: bold">{point.y}%</span></div>',
            }
        }]
    },

    /**
     * In the chart load callback, add icons on top of the circular shapes
     */
    function callback() {

        // Move icon
        this.renderer.path()
            .attr({
                'stroke': '#303030',
                'stroke-linecap': 'round',
                'stroke-linejoin': 'round',
                'stroke-width': 2,
                'zIndex': 10
            })
            .translate(190, 26)
            .add(this.series[2].group);

        // Exercise icon
        this.renderer.path()
            .attr({
                'stroke': '#303030',
                'stroke-linecap': 'round',
                'stroke-linejoin': 'round',
                'stroke-width': 2,
                'zIndex': 10
            })
            .translate(190, 61)
            .add(this.series[2].group);

        // Stand icon
        this.renderer.path()
            .attr({
                'stroke': '#303030',
                'stroke-linecap': 'round',
                'stroke-linejoin': 'round',
                'stroke-width': 2,
                'zIndex': 10
            })
            .translate(190, 96)
            .add(this.series[2].group);
    });


});